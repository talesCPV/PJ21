#!/bin/bash
# Clone files to Github - https://github.com/talesCPV/PJ21.git

git init

git clone https://github.com/talesCPV/PJ21.git 


FILE=PJ21/pages

if [ -d "$FILE" ]; then

    echo ATUALIZANDO SISTEMA DE PASTAS

    rm -rf ../pages/
    mv PJ21/pages/ ../
    rm -rf ./PJ21/

else

    echo NAO FOI POSSIVEL BAIXAR OS ARQUIVOS, VERIFIQUE A SUA REDE.

fi

